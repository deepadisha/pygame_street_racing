# street-racing
The title of the program is street racing . The main objective of the program is car should not be crashed in the highway. We are focusing on developing a 2d street racing game using pygame. This will cover implementation of real time graphics, physical engine, as well as sound effect and background music. It has several levels and score is based on distance and time.
